import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <div className="relative">
      {/* Hero Section */}
      <div className="relative h-screen">
        <Image
          src="/images/hero.jpg"
          alt="Wadi Rum desert"
          fill
          className="object-cover"
          priority
        />
        <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
          <div className="text-center px-4 max-w-3xl">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Discover Jordan's Hidden Gems
            </h1>
            <p className="text-xl text-white mb-8">
              Experience the adventure of a lifetime with our expertly crafted
              tours through Jordan's most breathtaking landscapes.
            </p>
            <div className="space-x-4">
              <Link
                href="/tours"
                className="inline-block px-6 py-3 bg-primary text-white font-medium rounded-lg hover:bg-primary/90 transition"
              >
                Explore Tours
              </Link>
              <Link
                href="/contact"
                className="inline-block px-6 py-3 bg-white text-primary font-medium rounded-lg hover:bg-gray-100 transition"
              >
                Contact Us
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Featured Tours */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our Popular Adventures
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Carefully curated experiences that showcase the best of Jordan's
              natural beauty and cultural heritage.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[
              {
                id: 1,
                title: "Wadi Rum Desert Expedition",
                description:
                  "3-day camping under the stars with jeep tours and Bedouin experiences.",
                price: "$350",
                duration: "3 days",
                image: "/images/wadi-rum.jpg",
              },
              {
                id: 2,
                title: "Petra & Dead Sea Combo",
                description:
                  "Explore the ancient city of Petra and float in the Dead Sea.",
                price: "$450",
                duration: "4 days",
                image: "/images/petra.jpg",
              },
              {
                id: 3,
                title: "Dana Biosphere Reserve Trek",
                description:
                  "Multi-day hiking through Jordan's most diverse nature reserve.",
                price: "$300",
                duration: "2 days",
                image: "/images/dana.jpg",
              },
            ].map((tour) => (
              <div
                key={tour.id}
                className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition"
              >
                <div className="relative h-48">
                  <Image
                    src={tour.image}
                    alt={tour.title}
                    fill
                    className="object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {tour.title}
                  </h3>
                  <p className="text-gray-600 mb-4">{tour.description}</p>
                  <div className="flex justify-between items-center">
                    <span className="text-primary font-bold">{tour.price}</span>
                    <span className="text-gray-500">{tour.duration}</span>
                  </div>
                  <Link
                    href={`/tours/${tour.id}`}
                    className="mt-4 inline-block w-full text-center bg-primary hover:bg-primary/90 text-white py-2 px-4 rounded transition"
                  >
                    View Details
                  </Link>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link
              href="/tours"
              className="inline-block px-6 py-3 border-2 border-primary text-primary font-medium rounded-lg hover:bg-primary hover:text-white transition"
            >
              View All Tours
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Why Choose Jordan Adventure Tours
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We go above and beyond to make your Jordanian adventure
              unforgettable.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                icon: "🏨",
                title: "Comfortable Accommodation",
                description:
                  "We partner with the best local hotels and camps to ensure your comfort.",
              },
              {
                icon: "🍽️",
                title: "Delicious Local Cuisine",
                description:
                  "Experience authentic Jordanian meals prepared with fresh ingredients.",
              },
              {
                icon: "🚐",
                title: "Reliable Transportation",
                description:
                  "Modern, air-conditioned vehicles with experienced drivers.",
              },
              {
                icon: "🗺️",
                title: "Expert Guides",
                description:
                  "Knowledgeable local guides who speak multiple languages.",
              },
              {
                icon: "🔒",
                title: "Safety First",
                description:
                  "All our activities meet the highest safety standards.",
              },
              {
                icon: "💯",
                title: "100% Satisfaction",
                description:
                  "We're committed to making your trip truly memorable.",
              },
            ].map((feature, index) => (
              <div
                key={index}
                className="bg-gray-50 p-6 rounded-lg text-center"
              >
                <div className="text-4xl mb-4">{feature.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              What Our Guests Say
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Don't just take our word for it - hear from our satisfied
              customers.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Sarah Johnson",
                location: "London, UK",
                review:
                  "The Wadi Rum experience was magical. The guides were knowledgeable and the overnight stay in the desert was unforgettable.",
                rating: 5,
              },
              {
                name: "Michael Chen",
                location: "Toronto, Canada",
                review:
                  "Petra was breathtaking, but what made it special was our guide's insights into Nabatean history. Highly recommend!",
                rating: 5,
              },
              {
                name: "Elena Rodriguez",
                location: "Madrid, Spain",
                review:
                  "Excellent organization from start to finish. Every detail was taken care of, allowing us to just enjoy the adventure.",
                rating: 5,
              },
            ].map((testimonial, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-lg shadow-sm"
              >
                <div className="flex items-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <svg
                      key={i}
                      className={`w-5 h-5 ${
                        i < testimonial.rating
                          ? "text-yellow-400"
                          : "text-gray-300"
                      }`}
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118l-2.8-2.034c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                    </svg>
                  ))}
                </div>
                <p className="text-gray-600 mb-4 italic">
                  "{testimonial.review}"
                </p>
                <div className="font-medium text-gray-900">
                  {testimonial.name}
                </div>
                <div className="text-gray-500 text-sm">
                  {testimonial.location}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-primary text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-6">
            Ready for Your Jordanian Adventure?
          </h2>
          <p className="text-xl mb-8 max-w-3xl mx-auto">
            Contact us today to start planning your perfect trip. Our team is
            ready to help you create unforgettable memories.
          </p>
          <div className="space-x-4">
            <Link
              href="/contact"
              className="inline-block px-6 py-3 bg-white text-primary font-medium rounded-lg hover:bg-gray-100 transition"
            >
              Get in Touch
            </Link>
            <Link
              href="/bookings"
              className="inline-block px-6 py-3 border-2 border-white text-white font-medium rounded-lg hover:bg-white hover:text-primary transition"
            >
              Book Now
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}