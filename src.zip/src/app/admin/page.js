'use client'
import { useState, useEffect } from 'react'
import TourForm from '../components/TourForm'

export default function AdminPanel() {
  const [tours, setTours] = useState([])
  const [editingTour, setEditingTour] = useState(null)
  const [isLoading, setIsLoading] = useState(true)

  const fetchTours = async () => {
    try {
      setIsLoading(true)
      const res = await fetch('http://localhost:5000/api/tours')
      const data = await res.json()
      setTours(data)
    } catch (error) {
      console.error('Error fetching tours:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleSave = async (tourData) => {
    try {
      const url = editingTour 
        ? `http://localhost:5000/api/tours/${editingTour._id}`
        : 'http://localhost:5000/api/tours'
      
      const method = editingTour ? 'PUT' : 'POST'

      const response = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(tourData)
      })

      if (!response.ok) throw new Error('Failed to save tour')

      fetchTours()
      setEditingTour(null)
    } catch (error) {
      console.error('Error saving tour:', error)
      alert('Failed to save tour. Please try again.')
    }
  }

  const handleDelete = async (id) => {
    if (!confirm('Are you sure you want to delete this tour?')) return
    
    try {
      const response = await fetch(`http://localhost:5000/api/tours/${id}`, {
        method: 'DELETE'
      })

      if (!response.ok) throw new Error('Failed to delete tour')

      fetchTours()
    } catch (error) {
      console.error('Error deleting tour:', error)
      alert('Failed to delete tour. Please try again.')
    }
  }

  useEffect(() => {
    fetchTours()
  }, [])

  if (isLoading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Tour Management</h1>
        {!editingTour && (
          <button
            onClick={() => setEditingTour({})}
            className="bg-primary hover:bg-primary/90 text-white px-4 py-2 rounded-lg"
          >
            Add New Tour
          </button>
        )}
      </div>

      {editingTour ? (
        <TourForm 
          tour={editingTour} 
          onSave={handleSave}
          onCancel={() => setEditingTour(null)}
        />
      ) : (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tour</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Duration</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Difficulty</th>
                  <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {tours.map((tour) => (
                  <tr key={tour._id}>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-10 w-10">
                          <img className="h-10 w-10 rounded-full object-cover" src={tour.image} alt={tour.title} />
                        </div>
                        <div className="ml-4">
                          <div className="text-sm font-medium text-gray-900">{tour.title}</div>
                          <div className="text-sm text-gray-500 line-clamp-1">{tour.description.substring(0, 50)}...</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      ${tour.price}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {tour.duration}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                        tour.difficulty === 'Easy' ? 'bg-green-100 text-green-800' :
                        tour.difficulty === 'Moderate' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-red-100 text-red-800'
                      }`}>
                        {tour.difficulty}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                      <button
                        onClick={() => setEditingTour(tour)}
                        className="text-primary hover:text-primary/80 mr-4"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => handleDelete(tour._id)}
                        className="text-red-600 hover:text-red-900"
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  )
}