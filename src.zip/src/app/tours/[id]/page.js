import Image from "next/image";
import Link from "next/link";

async function getTour(id) {
  // In a real app, this would fetch from your API
  const tours = [
    {
      id: 1,
      title: "Wadi Rum Desert Expedition",
      description:
        "Experience the magic of Jordan's desert landscape with our 3-day Wadi Rum adventure. Sleep under the stars in traditional Bedouin camps, explore hidden canyons by 4x4, and witness breathtaking sunsets over the Martian-like landscape.",
      price: 350,
      duration: "3 days",
      difficulty: "Moderate",
      groupSize: "4-12 people",
      image: "/images/wadi-rum.jpg",
      highlights: [
        "Jeep safari through Wadi Rum",
        "Overnight in luxury Bedouin camp",
        "Sunset and sunrise views",
        "Traditional Jordanian meals",
      ],
      itinerary: [
        {
          day: 1,
          title: "Arrival in Wadi Rum",
          description:
            "Meet your guide at the Wadi Rum Visitor Center. Transfer to camp by 4x4 with stops at Lawrence Spring and Khazali Canyon. Sunset viewing followed by traditional dinner and overnight in the camp.",
        },
        {
          day: 2,
          title: "Full Day Desert Exploration",
          description:
            "Full day jeep tour visiting Burdah Rock Bridge, Um Fruth Rock Bridge, and the Anfashieh inscriptions. Lunch in the desert. Return to camp for sunset and dinner.",
        },
        {
          day: 3,
          title: "Departure",
          description:
            "Sunrise viewing and breakfast. Short morning hike before returning to the Visitor Center for departure.",
        },
      ],
      included: [
        "All transportation in Wadi Rum",
        "2 nights accommodation in luxury camp",
        "All meals (2 breakfasts, 2 lunches, 2 dinners)",
        "English-speaking guide",
        "All entrance fees",
      ],
      notIncluded: [
        "Transportation to/from Wadi Rum",
        "Personal expenses",
        "Tips for guides and staff",
      ],
    },
    // ... other tours would be here
  ];

  return tours.find((tour) => tour.id === parseInt(id));
}

export default async function TourDetailPage({ params }) {
  const tour = await getTour(params.id);

  if (!tour) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl font-bold mb-4">Tour Not Found</h1>
          <Link
            href="/tours"
            className="text-primary hover:underline"
          >
            Back to all tours
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <Link
            href="/tours"
            className="text-primary hover:underline flex items-center"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              className="h-5 w-5 mr-1"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z"
                clipRule="evenodd"
              />
            </svg>
            Back to all tours
          </Link>
        </div>

        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="relative h-96">
            <Image
              src={tour.image}
              alt={tour.title}
              fill
              className="object-cover"
            />
          </div>

          <div className="p-6 md:p-8">
            <div className="flex flex-col md:flex-row md:justify-between md:items-start gap-6">
              <div className="md:w-2/3">
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  {tour.title}
                </h1>
                <p className="text-xl text-gray-600 mb-6">{tour.description}</p>

                <div className="mb-8">
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    Tour Highlights
                  </h2>
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {tour.highlights.map((highlight, index) => (
                      <li key={index} className="flex items-start">
                        <svg
                          className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path
                            fillRule="evenodd"
                            d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                            clipRule="evenodd"
                          />
                        </svg>
                        <span className="text-gray-700">{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="mb-8">
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                    Itinerary
                  </h2>
                  <div className="space-y-6">
                    {tour.itinerary.map((day) => (
                      <div key={day.day} className="flex">
                        <div className="flex flex-col items-center mr-4">
                          <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary text-white font-bold">
                            {day.day}
                          </div>
                          <div className="w-px h-full bg-gray-300 mt-2"></div>
                        </div>
                        <div className="pb-6">
                          <h3 className="text-lg font-semibold text-gray-900 mb-1">
                            {day.title}
                          </h3>
                          <p className="text-gray-600">{day.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="md:w-1/3">
                <div className="bg-gray-50 rounded-lg p-6 sticky top-6">
                  <div className="mb-6">
                    <h2 className="text-xl font-semibold text-gray-900 mb-2">
                      Tour Details
                    </h2>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Duration:</span>
                        <span className="font-medium">{tour.duration}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Difficulty:</span>
                        <span className="font-medium">{tour.difficulty}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Group Size:</span>
                        <span className="font-medium">{tour.groupSize}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Price:</span>
                        <span className="text-primary font-bold">
                          ${tour.price}
                        </span>
                      </div>
                    </div>
                  </div>

                  <Link
                    href={`/bookings?tour=${tour.id}`}
                    className="block w-full bg-primary hover:bg-primary/90 text-white text-center font-medium py-3 px-4 rounded-lg transition"
                  >
                    Book This Tour
                  </Link>
                </div>
              </div>
            </div>

            <div className="mt-12 grid grid-cols-1 md:grid-cols-2 gap-8">
              <div>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                  What's Included
                </h2>
                <ul className="space-y-2">
                  {tour.included.map((item, index) => (
                    <li key={index} className="flex items-start">
                      <svg
                        className="h-5 w-5 text-primary mt-0.5 mr-2 flex-shrink-0"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h2 className="text-2xl font-semibold text-gray-900 mb-4">
                  Not Included
                </h2>
                <ul className="space-y-2">
                  {tour.notIncluded.map((item, index) => (
                    <li key={index} className="flex items-start">
                      <svg
                        className="h-5 w-5 text-gray-400 mt-0.5 mr-2 flex-shrink-0"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                          clipRule="evenodd"
                        />
                      </svg>
                      <span className="text-gray-700">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}