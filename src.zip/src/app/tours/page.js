import Link from "next/link";
import Image from "next/image";

async function getTours() {
  // In a real app, this would fetch from your API
  return [
    {
      id: 1,
      title: "Wadi Rum Desert Expedition",
      description:
        "Experience the magic of Jordan's desert landscape with our 3-day Wadi Rum adventure. Sleep under the stars in traditional Bedouin camps, explore hidden canyons by 4x4, and witness breathtaking sunsets over the Martian-like landscape.",
      price: 350,
      duration: "3 days",
      difficulty: "Moderate",
      groupSize: "4-12 people",
      image: "/images/wadi-rum.jpg",
      highlights: [
        "Jeep safari through Wadi Rum",
        "Overnight in luxury Bedouin camp",
        "Sunset and sunrise views",
        "Traditional Jordanian meals",
      ],
    },
    {
      id: 2,
      title: "Petra & Dead Sea Combo",
      description:
        "Combine two of Jordan's most iconic destinations in one unforgettable trip. Explore the ancient Nabatean city of Petra, then relax and float in the mineral-rich waters of the Dead Sea.",
      price: 450,
      duration: "4 days",
      difficulty: "Easy",
      groupSize: "6-15 people",
      image: "/images/petra.jpg",
      highlights: [
        "Full day exploring Petra",
        "Dead Sea resort stay",
        "Guided tour of Little Petra",
        "Buffet dinners included",
      ],
    },
    {
      id: 3,
      title: "Dana Biosphere Reserve Trek",
      description:
        "For nature lovers, this 2-day trek through Dana Biosphere Reserve offers stunning landscapes, diverse wildlife, and a chance to experience Jordan's natural beauty up close.",
      price: 300,
      duration: "2 days",
      difficulty: "Challenging",
      groupSize: "4-8 people",
      image: "/images/dana.jpg",
      highlights: [
        "Guided hike through diverse ecosystems",
        "Local community homestay",
        "Birdwatching opportunities",
        "Traditional meals with local families",
      ],
    },
    {
      id: 4,
      title: "Jerash & Ajloun Castle Day Trip",
      description:
        "Discover Jordan's rich history with a day trip to the ancient Roman city of Jerash and the medieval Ajloun Castle. Perfect for history buffs and those with limited time.",
      price: 120,
      duration: "1 day",
      difficulty: "Easy",
      groupSize: "2-10 people",
      image: "/images/jerash.jpg",
      highlights: [
        "Guided tour of Jerash ruins",
        "Visit to Ajloun Castle",
        "Lunch at local restaurant",
        "Round-trip transportation",
      ],
    },
    {
      id: 5,
      title: "Red Sea Diving Package",
      description:
        "Explore Jordan's underwater world in Aqaba with this 3-day diving package. Suitable for both beginners and certified divers, with options for PADI certification courses.",
      price: 400,
      duration: "3 days",
      difficulty: "Moderate",
      groupSize: "2-6 people",
      image: "/images/aqaba.jpg",
      highlights: [
        "2 boat dives per day",
        "Equipment rental included",
        "Beachfront accommodation",
        "Optional night dive",
      ],
    },
    {
      id: 6,
      title: "Jordan Highlights Tour",
      description:
        "Our comprehensive 7-day tour covers all of Jordan's must-see destinations: Amman, Jerash, Petra, Wadi Rum, the Dead Sea, and Aqaba. Perfect for first-time visitors.",
      price: 850,
      duration: "7 days",
      difficulty: "Moderate",
      groupSize: "4-12 people",
      image: "/images/jordan-highlights.jpg",
      highlights: [
        "All major Jordan attractions",
        "Luxury accommodations",
        "Most meals included",
        "Private transportation",
      ],
    },
  ];
}

export default async function ToursPage() {
  const tours = await getTours();

  return (
    <div className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Our Adventure Tours
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover the best of Jordan with our carefully crafted adventure
            tours. From ancient cities to breathtaking natural wonders, we've got
            something for every traveler.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {tours.map((tour) => (
            <div
              key={tour.id}
              className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition"
            >
              <div className="relative h-48">
                <Image
                  src={tour.image}
                  alt={tour.title}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-6">
                <h2 className="text-xl font-semibold text-gray-900 mb-2">
                  {tour.title}
                </h2>
                <div className="flex justify-between items-center mb-3">
                  <span className="text-primary font-bold">
                    ${tour.price}
                  </span>
                  <span className="text-gray-500">{tour.duration}</span>
                </div>
                <p className="text-gray-600 mb-4 line-clamp-2">
                  {tour.description}
                </p>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-500">
                    {tour.difficulty} • {tour.groupSize}
                  </span>
                  <Link
                    href={`/tours/${tour.id}`}
                    className="text-primary hover:text-primary/80 font-medium"
                  >
                    View Details →
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}