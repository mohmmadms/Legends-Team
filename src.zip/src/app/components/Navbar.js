import Link from "next/link";

const Navbar = () => {
  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0 flex items-center">
              <img
                className="h-8 w-auto"
                src="/images/logo.png"
                alt="Jordan Adventure Tours"
              />
              <span className="ml-2 text-xl font-bold text-primary">
                Legends Team
              </span>
            </Link>
          </div>
          <div className="hidden md:ml-6 md:flex md:items-center md:space-x-8">
            <Link
              href="/"
              className="text-gray-900 hover:text-primary px-3 py-2 text-sm font-medium"
            >
              Home
            </Link>
            <Link
              href="/tours"
              className="text-gray-900 hover:text-primary px-3 py-2 text-sm font-medium"
            >
              Tours
            </Link>
            <Link
              href="/about"
              className="text-gray-900 hover:text-primary px-3 py-2 text-sm font-medium"
            >
              About Us
            </Link>
            <Link
              href="/contact"
              className="text-gray-900 hover:text-primary px-3 py-2 text-sm font-medium"
            >
              Contact
            </Link>
            <Link
              href="/bookings"
              className="ml-8 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary hover:bg-primary/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary"
            >
              Book Now
            </Link>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;