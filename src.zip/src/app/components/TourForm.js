'use client'
import { useState } from 'react'

export default function TourForm({ tour, onSave }) {
  const [formData, setFormData] = useState(tour || {
    title: '',
    description: '',
    price: 0,
    duration: '',
    difficulty: 'Moderate',
    groupSize: '',
    highlights: [''],
    itinerary: [{ day: 1, title: '', description: '' }],
    included: [''],
    notIncluded: [''],
    image: ''
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: name === 'price' ? Number(value) : value
    }))
  }

  const handleArrayChange = (field, index, value) => {
    setFormData(prev => {
      const newArray = [...prev[field]]
      newArray[index] = value
      return { ...prev, [field]: newArray }
    })
  }

  const handleItineraryChange = (index, field, value) => {
    setFormData(prev => {
      const newItinerary = [...prev.itinerary]
      newItinerary[index][field] = field === 'day' ? Number(value) : value
      return { ...prev, itinerary: newItinerary }
    })
  }

  const addArrayItem = (field) => {
    setFormData(prev => ({
      ...prev,
      [field]: field === 'itinerary' 
        ? [...prev[field], { day: prev[field].length + 1, title: '', description: '' }]
        : [...prev[field], '']
    }))
  }

  const removeArrayItem = (field, index) => {
    setFormData(prev => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index)
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    onSave(formData)
  }

  return (
    <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow-md">
      <h2 className="text-2xl font-bold text-primary mb-6">
        {tour ? 'Edit Tour' : 'Create New Tour'}
      </h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        {/* Basic Information */}
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Title*</label>
            <input
              type="text"
              name="title"
              value={formData.title}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Description*</label>
            <textarea
              name="description"
              value={formData.description}
              onChange={handleChange}
              rows="4"
              className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
              required
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Image URL*</label>
            <input
              type="text"
              name="image"
              value={formData.image}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
              required
            />
          </div>
        </div>

        {/* Pricing & Details */}
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Price ($)*</label>
              <input
                type="number"
                name="price"
                value={formData.price}
                onChange={handleChange}
                min="0"
                className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Duration*</label>
              <input
                type="text"
                name="duration"
                value={formData.duration}
                onChange={handleChange}
                className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Difficulty*</label>
            <select
              name="difficulty"
              value={formData.difficulty}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
              required
            >
              <option value="Easy">Easy</option>
              <option value="Moderate">Moderate</option>
              <option value="Challenging">Challenging</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Group Size*</label>
            <input
              type="text"
              name="groupSize"
              value={formData.groupSize}
              onChange={handleChange}
              className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
              required
            />
          </div>
        </div>
      </div>

      {/* Highlights */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">Highlights*</label>
        {formData.highlights.map((highlight, index) => (
          <div key={index} className="flex gap-2 mb-2">
            <input
              type="text"
              value={highlight}
              onChange={(e) => handleArrayChange('highlights', index, e.target.value)}
              className="flex-1 p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
              required
            />
            <button
              type="button"
              onClick={() => removeArrayItem('highlights', index)}
              className="bg-red-500 text-white px-3 rounded hover:bg-red-600"
            >
              ×
            </button>
          </div>
        ))}
        <button
          type="button"
          onClick={() => addArrayItem('highlights')}
          className="mt-2 bg-gray-200 text-gray-700 px-3 py-1 rounded text-sm hover:bg-gray-300"
        >
          + Add Highlight
        </button>
      </div>

      {/* Itinerary */}
      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">Itinerary*</label>
        {formData.itinerary.map((day, index) => (
          <div key={index} className="mb-4 p-3 border border-gray-200 rounded">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 mb-2">
              <div>
                <label className="block text-xs text-gray-500 mb-1">Day</label>
                <input
                  type="number"
                  value={day.day}
                  onChange={(e) => handleItineraryChange(index, 'day', e.target.value)}
                  min="1"
                  className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
                  required
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-xs text-gray-500 mb-1">Title</label>
                <input
                  type="text"
                  value={day.title}
                  onChange={(e) => handleItineraryChange(index, 'title', e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
                  required
                />
              </div>
            </div>
            <div>
              <label className="block text-xs text-gray-500 mb-1">Description</label>
              <textarea
                value={day.description}
                onChange={(e) => handleItineraryChange(index, 'description', e.target.value)}
                rows="2"
                className="w-full p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
                required
              />
            </div>
            <button
              type="button"
              onClick={() => removeArrayItem('itinerary', index)}
              className="mt-2 bg-red-500 text-white px-2 py-1 rounded text-sm hover:bg-red-600"
            >
              Remove Day
            </button>
          </div>
        ))}
        <button
          type="button"
          onClick={() => addArrayItem('itinerary')}
          className="mt-2 bg-gray-200 text-gray-700 px-3 py-1 rounded text-sm hover:bg-gray-300"
        >
          + Add Day
        </button>
      </div>

      {/* Included/Not Included */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">What's Included*</label>
          {formData.included.map((item, index) => (
            <div key={index} className="flex gap-2 mb-2">
              <input
                type="text"
                value={item}
                onChange={(e) => handleArrayChange('included', index, e.target.value)}
                className="flex-1 p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
                required
              />
              <button
                type="button"
                onClick={() => removeArrayItem('included', index)}
                className="bg-red-500 text-white px-3 rounded hover:bg-red-600"
              >
                ×
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() => addArrayItem('included')}
            className="mt-2 bg-gray-200 text-gray-700 px-3 py-1 rounded text-sm hover:bg-gray-300"
          >
            + Add Item
          </button>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Not Included*</label>
          {formData.notIncluded.map((item, index) => (
            <div key={index} className="flex gap-2 mb-2">
              <input
                type="text"
                value={item}
                onChange={(e) => handleArrayChange('notIncluded', index, e.target.value)}
                className="flex-1 p-2 border border-gray-300 rounded focus:ring-primary focus:border-primary"
                required
              />
              <button
                type="button"
                onClick={() => removeArrayItem('notIncluded', index)}
                className="bg-red-500 text-white px-3 rounded hover:bg-red-600"
              >
                ×
              </button>
            </div>
          ))}
          <button
            type="button"
            onClick={() => addArrayItem('notIncluded')}
            className="mt-2 bg-gray-200 text-gray-700 px-3 py-1 rounded text-sm hover:bg-gray-300"
          >
            + Add Item
          </button>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          className="bg-primary hover:bg-primary/90 text-white font-medium py-2 px-6 rounded-lg transition"
        >
          {tour ? 'Update Tour' : 'Create Tour'}
        </button>
      </div>
    </form>
  )
}