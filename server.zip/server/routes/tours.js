const express = require("express");
const Tour = require("../models/Tour");
const router = express.Router();

// Get all tours
router.get("/", async (req, res) => {
  try {
    const tours = await Tour.find({});
    res.json(tours);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get single tour
router.get("/:id", async (req, res) => {
  try {
    const tour = await Tour.findById(req.params.id);
    if (!tour) {
      return res.status(404).json({ message: "Tour not found" });
    }
    res.json(tour);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Create tour (admin only)
router.post("/", async (req, res) => {
  const tour = new Tour(req.body);
  try {
    const newTour = await tour.save();
    res.status(201).json(newTour);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Update tour (admin only)
router.put("/:id", async (req, res) => {
  try {
    const updatedTour = await Tour.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    if (!updatedTour) {
      return res.status(404).json({ message: "Tour not found" });
    }
    res.json(updatedTour);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete tour (admin only)
router.delete("/:id", async (req, res) => {
  try {
    const deletedTour = await Tour.findByIdAndDelete(req.params.id);
    if (!deletedTour) {
      return res.status(404).json({ message: "Tour not found" });
    }
    res.json({ message: "Tour deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;