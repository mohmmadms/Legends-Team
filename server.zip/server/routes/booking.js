const express = require("express");
const Booking = require("../models/Booking");
const Tour = require("../models/Tour");
const nodemailer = require("nodemailer");
const router = express.Router();

// Configure email transporter
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS
  }
});

// Create booking
router.post("/", async (req, res) => {
  try {
    const tour = await Tour.findById(req.body.tour);
    if (!tour) {
      return res.status(404).json({ message: "Tour not found" });
    }

    const booking = new Booking({
      ...req.body,
      totalPrice: tour.price * req.body.participants,
    });

    await booking.save();

    // Send email notification
    const mailOptions = {
      from: process.env.EMAIL_USER,
      to: process.env.ADMIN_EMAIL,
      subject: `New Booking: ${tour.title}`,
      html: `
        <h2>New Booking Received</h2>
        <p><strong>Tour:</strong> ${tour.title}</p>
        <p><strong>Date:</strong> ${new Date(req.body.date).toLocaleDateString()}</p>
        <p><strong>Participants:</strong> ${req.body.participants}</p>
        <p><strong>Total Price:</strong> $${booking.totalPrice}</p>
        <h3>Customer Details</h3>
        <p><strong>Name:</strong> ${req.body.name}</p>
        <p><strong>Email:</strong> ${req.body.email}</p>
        <p><strong>Phone:</strong> ${req.body.phone}</p>
        <p><strong>Special Requests:</strong> ${req.body.specialRequests || 'None'}</p>
      `
    };

    await transporter.sendMail(mailOptions);

    // Send confirmation email to customer
    const customerMailOptions = {
      from: process.env.EMAIL_USER,
      to: req.body.email,
      subject: `Booking Confirmation: ${tour.title}`,
      html: `
        <h2>Thank you for your booking!</h2>
        <p>We've received your booking request for <strong>${tour.title}</strong>.</p>
        <h3>Booking Details</h3>
        <p><strong>Date:</strong> ${new Date(req.body.date).toLocaleDateString()}</p>
        <p><strong>Participants:</strong> ${req.body.participants}</p>
        <p><strong>Total Amount:</strong> $${booking.totalPrice}</p>
        <p>Our team will contact you shortly to confirm your booking.</p>
        <p>If you have any questions, please reply to this email.</p>
      `
    };

    await transporter.sendMail(customerMailOptions);

    res.status(201).json(booking);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Create booking
router.post("/", auth, async (req, res) => {
  try {
    const tour = await Tour.findById(req.body.tour);
    if (!tour) {
      return res.status(404).json({ message: "Tour not found" });
    }

    const booking = new Booking({
      ...req.body,
      user: req.user._id,
      totalPrice: tour.price * req.body.participants,
    });

    await booking.save();
    res.status(201).json(booking);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Get user's bookings
router.get("/my-bookings", auth, async (req, res) => {
  try {
    const bookings = await Booking.find({ user: req.user._id }).populate(
      "tour"
    );
    res.json(bookings);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Get single booking
router.get("/:id", auth, async (req, res) => {
  try {
    const booking = await Booking.findOne({
      _id: req.params.id,
      user: req.user._id,
    }).populate("tour");
    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }
    res.json(booking);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Cancel booking
router.put("/:id/cancel", auth, async (req, res) => {
  try {
    const booking = await Booking.findOneAndUpdate(
      {
        _id: req.params.id,
        user: req.user._id,
        status: { $ne: "cancelled" },
      },
      { status: "cancelled" },
      { new: true }
    ).populate("tour");

    if (!booking) {
      return res.status(404).json({ message: "Booking not found" });
    }
    res.json(booking);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

module.exports = router;