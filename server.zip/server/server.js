require("dotenv").config();
const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const connectDB = require("./config/db");

// Initialize Express app
const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Database connection
connectDB();


// Routes

app.use('/api/contact', contactRouter)
app.use("/api/tours", require("./routes/tours"));
app.use("/api/bookings", require("./routes/bookings"));
app.use("/api/users", require("./routes/users"));



// Basic route
app.get("/", (req, res) => {
  res.send("Jordan Adventure Tours API");
});

// API routes would go here
// app.use("/api/tours", require("./routes/tours"));
// app.use("/api/bookings", require("./routes/bookings"));

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});